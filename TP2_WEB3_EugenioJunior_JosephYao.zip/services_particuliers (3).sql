-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : dim. 16 nov. 2025 à 16:58
-- Version du serveur : 9.1.0
-- Version de PHP : 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `services_particuliers`
--

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id_categorie` int NOT NULL AUTO_INCREMENT,
  `nom_categorie` varchar(100) NOT NULL,
  `description` text,
  PRIMARY KEY (`id_categorie`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`id_categorie`, `nom_categorie`, `description`) VALUES
(1, 'Jardinage', 'Services liés à l’entretien des espaces verts, pelouses, haies et aménagements paysagers.'),
(2, 'Informatique', 'Services de réparation, assistance et formation dans le domaine des technologies.'),
(3, 'Entretien ménager', 'Services de nettoyage résidentiel et commercial.'),
(4, 'Transport et déménagement', 'Services de livraison, déménagement et transport de biens.'),
(5, 'Cours particuliers', 'Soutien scolaire et formation dans diverses matières et activités.');

-- --------------------------------------------------------

--
-- Structure de la table `compte`
--

DROP TABLE IF EXISTS `compte`;
CREATE TABLE IF NOT EXISTS `compte` (
  `id_compte` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `mdp` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `role` enum('admin','utilisateur') NOT NULL,
  `credit` int NOT NULL,
  PRIMARY KEY (`id_compte`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `compte`
--

INSERT INTO `compte` (`id_compte`, `nom`, `mdp`, `role`, `credit`) VALUES
(12, 'alex.dupont@gmail.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(13, 'marie.lavoie@hotmail.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(14, 'simon.bergeron@yahoo.ca', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(15, 'emma.tremblay@gmail.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(16, 'nathan.roy@outlook.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(17, 'julie.fortin@gmail.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(18, 'lucas.perron@gmail.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(19, 'amelie.gagne@hotmail.ca', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(20, 'kevin.bouchard@gmail.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(21, 'sarah.leblanc@videotron.ca', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(24, 'marie.lavoie@hotmail.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(25, 'simon.bergeron@yahoo.ca', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(26, 'emma.tremblay@gmail.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(27, 'nathan.roy@outlook.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(28, 'julie.fortin@gmail.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(29, 'lucas.perron@gmail.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(30, 'amelie.gagne@hotmail.ca', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(31, 'kevin.bouchard@gmail.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(32, 'sarah.leblanc@videotron.ca', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(33, 'antoine.morin@gmail.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(34, 'clara.deschamps@yahoo.ca', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(35, 'yoan.leroux@hotmail.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(36, 'sophie.renaud@gmail.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(37, 'jimmy.paquin@outlook.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(38, 'melissa.darveau@gmail.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(39, 'victor.ouellet@live.ca', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(40, 'amelia.carrier@gmail.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(41, 'gabriel.fontaine@yahoo.ca', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(42, 'olivia.marchand@gmail.com', '6aea085563e1a50b3828b6fcfc6264b2f2e0e9ddf940d0c1fb509d9fb7177579aa3ada1d56ca779d93ed96ca78664f3cd509806df67aeb0f919a91127b1b51f9', 'utilisateur', 0),
(43, 'admin@garneau.ca', 'e6065d6c3350792f283cdb5aa772a13c9393a453b06c96b24da38661a8baeeeb38b123647d7fd1e9873b1d6fe30a75451f83deebf5de17c0c52cc87485a66766', 'admin', 0);

-- --------------------------------------------------------

--
-- Structure de la table `services`
--

DROP TABLE IF EXISTS `services`;
CREATE TABLE IF NOT EXISTS `services` (
  `id_service` int NOT NULL AUTO_INCREMENT,
  `id_categorie` int NOT NULL,
  `proprietaire` int NOT NULL,
  `titre` varchar(50) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `localisation` varchar(50) NOT NULL,
  `date_creation` datetime DEFAULT CURRENT_TIMESTAMP,
  `actif` tinyint(1) DEFAULT '1',
  `cout` decimal(8,2) DEFAULT '0.00',
  `photo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_service`),
  KEY `id_categorie` (`id_categorie`),
  KEY `fk_proprio` (`proprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `services`
--

INSERT INTO `services` (`id_service`, `id_categorie`, `proprietaire`, `titre`, `description`, `localisation`, `date_creation`, `actif`, `cout`, `photo`) VALUES
(34, 1, 12, 'Tonte de pelouse', 'Tonte professionnelle avec coupe-bordure et ramassage.', 'Québec', '2025-11-15 11:25:09', 1, 35.00, 'pelouse1.jpg'),
(35, 1, 18, 'Taille de haies', 'Taille de haies, arbustes, et nettoyage complet.', 'Beauport', '2025-11-15 11:25:09', 1, 55.00, 'haies1.jpg'),
(36, 1, 20, 'Déneigement entrée', 'Déneigement manuel de l’entrée et des marches.', 'Charlesbourg', '2025-11-15 11:25:09', 1, 25.00, 'neige.jpg'),
(37, 1, 28, 'Plantation de jardins', 'Plantation de fleurs et légumes selon vos préférences.', 'Lévis', '2025-11-15 11:25:09', 1, 40.00, 'plants.jpg'),
(38, 1, 17, 'Entretien complet terrain', 'Service mensuel incluant tonte, haies, arrosage.', 'Québec', '2025-11-15 11:25:09', 1, 90.00, 'terrain.jpg'),
(39, 2, 14, 'Réparation PC', 'Réparation, nettoyage interne et optimisation complète.', 'Québec', '2025-11-15 11:25:09', 1, 60.00, 'pcfix1.jpg'),
(40, 2, 16, 'Installation Windows', 'Installation Windows 10/11 + optimisation.', 'Sainte-Foy', '2025-11-15 11:25:09', 1, 45.00, 'windows.jpg'),
(41, 2, 25, 'Montage PC gamer', 'Montage professionnel, test de stabilité et câblage.', 'Limoilou', '2025-11-15 11:25:09', 1, 80.00, 'pcbuild.jpg'),
(43, 2, 26, 'Nettoyage virus', 'Suppression virus/malware + optimisation.', 'Québec', '2025-11-15 11:25:09', 1, 40.00, 'virus.jpg'),
(44, 3, 15, 'Ménage résidentiel', 'Nettoyage complet cuisine, salle de bain, planchers.', 'Québec', '2025-11-15 11:25:09', 1, 75.00, 'menage1.jpg'),
(45, 3, 21, 'Lavage de vitres', 'Vitres intérieures et extérieures (rez-de-chaussée).', 'Lévis', '2025-11-15 11:25:09', 1, 50.00, 'vitres.jpg'),
(46, 3, 24, 'Nettoyage intensif', 'Grand ménage complet avant inspection.', 'Sillery', '2025-11-15 11:25:09', 1, 120.00, 'intensif.jpg'),
(47, 3, 30, 'Nettoyage bureaux', 'Entretien commercial hebdomadaire.', 'Québec', '2025-11-15 11:25:09', 1, 150.00, 'bureau.jpg'),
(48, 3, 27, 'Désinfection complète', 'Désinfection pièces communes et surfaces.', 'Beauport', '2025-11-15 11:25:09', 1, 65.00, 'sanitize.jpg'),
(50, 4, 18, 'Livraison locale', 'Livraison petites marchandises Québec–Lévis.', 'Québec', '2025-11-15 11:25:09', 1, 25.00, 'livraison.jpg'),
(51, 4, 29, 'Transport sofa', 'Transport de gros meubles (sofa, matelas, etc.).', 'Charlesbourg', '2025-11-15 11:25:09', 1, 70.00, 'sofa.jpg'),
(52, 4, 21, 'Aide déménagement', 'Aide à l’emballage et chargement/déchargement.', 'Limoilou', '2025-11-15 11:25:09', 1, 60.00, 'box.jpg'),
(53, 4, 13, 'Transport express', 'Livraison urgente le jour même.', 'Québec', '2025-11-15 11:25:09', 1, 40.00, 'express.jpg'),
(54, 5, 12, 'Cours de math', 'Soutien scolaire secondaire 1–5.', 'En ligne', '2025-11-15 11:25:09', 1, 30.00, 'math.jpg'),
(55, 5, 17, 'Cours d’anglais', 'Cours oral/écrit, niveaux débutant à avancé.', 'Québec', '2025-11-15 11:25:09', 1, 25.00, 'english.jpg'),
(56, 5, 26, 'Cours Excel avancé', 'Formules, tableaux croisés, automatisation.', 'En ligne', '2025-11-15 11:25:09', 1, 35.00, 'excel.jpg'),
(58, 5, 30, 'Préparation examens', 'Aide aux révisions + stratégie d’étude.', 'Sainte-Foy', '2025-11-15 11:25:09', 1, 28.00, 'exam.jpg'),
(59, 1, 29, 'Arrosage automatique', 'Installation de système d’arrosage.', 'Lévis', '2025-11-15 11:25:09', 1, 150.00, 'arrosage.jpg'),
(60, 2, 12, 'Support télétravail', 'Installation et configuration Zoom/VPN.', 'Québec', '2025-11-15 11:25:09', 1, 30.00, 'teletravail.jpg'),
(61, 3, 25, 'Nettoyage tapis', 'Shampoing à la machine de tapis et carpettes.', 'Québec', '2025-11-15 11:25:09', 1, 60.00, 'tapis.jpg'),
(62, 4, 27, 'Livraison Montréal–Québec', 'Transport interville à prix fixe.', 'Québec', '2025-11-15 11:25:09', 1, 120.00, 'interville.jpg'),
(63, 5, 24, 'Cours espagnol', 'Introduction à la langue espagnole.', 'En ligne', '2025-11-15 11:25:09', 1, 22.00, 'espagnol.jpg');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `services`
--
ALTER TABLE `services`
  ADD CONSTRAINT `services_ibfk_1` FOREIGN KEY (`id_categorie`) REFERENCES `categories` (`id_categorie`),
  ADD CONSTRAINT `services_ibfk_2` FOREIGN KEY (`proprietaire`) REFERENCES `compte` (`id_compte`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

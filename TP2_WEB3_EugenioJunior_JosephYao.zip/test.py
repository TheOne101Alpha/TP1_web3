from bd import hacher_mdp

# print(hacher_mdp('Qwerty_123'))


# print(hacher_mdp('admin'))

# print(repr('admin'))

print(repr('random_mdp'))